SELECT	dbo.udf_age_ymd(d.birthdate,a.registrydate),
		a.PK_psPatRegisters,
		b.PK_emdPatients,
		a.pattrantype,
		c.fullname,
		d.gender,
		d.civilstatus,
		d.mofullname,
		c.prstreetbldg1,
		c.prregion,
		c.prprovince,
		c.prtowncity,
		c.prbarangay,
		c.przipcode,
		c.prtelno,
		c.mobilephone,
		c.email,
		MONTH(d.birthdate) as month,
		DAY(d.birthdate) as day,
		YEAR(d.birthdate) as year,
		d.birthplace,
		d.religion,
		d.nationality,
		a.educationAttainment,
		d.occupation,
		d.company,
		d.philhealthID,
		e.*
  FROM	emdPatients b 
  JOIN	psDatacenter c 
    ON	c.PK_psDatacenter = b.pK_emdPatients
  JOIN	psPersonaldata d
	ON	d.PK_psPersonalData = b.pK_emdPatients
  JOIN	psPatRegisters a
	ON	a.FK_emdPatients = b.PK_emdPatients
  JOIN	[10.4.1.3\sqlcldh02].HealthInfoDB.dbo.PatHistoryCC e
	ON	b.PK_emdPatients = e.fk_emdpatients
 where  a.PK_psPatRegisters = 677382
