SELECT	                 
		d.patid,
		a.registryno,
		b.fullname,
		c.cpaddress,
		c.birthdate,
		c.gender,
		a.registrydate,
		a.mghdatetime,
		a.dischdate,
		a.dischdiagnosis,
		a.surgicalproc,
		a.FK_mscServiceType,
		g.description as  ServiceType,
		a.finaldiagnosis,
		a.finaldiagcode,
		a.impression,
		a.FK_mscAdmResults,
		f.description as AdmResult,
		a.pattrantype,
		e.prcno,
		dbo.udf_GetFullName(e.PK_emdDoctors) AS attendingPhysician
			--k.Position,
  --      j.FK_mscWarehouse,
  --      h.qty,
		--h.timestamp,
		--j.formName,
		--k.Lastname,k.Firstname, k.Middlename 
		
  FROM	psPatRegisters a
 -- JOIN	[10.4.1.3\sqlcldh02].[HealthInfoDB].[dbo].[psPatForms] h
	--ON	a.PK_psPatRegisters = h.FK_psPatRegisters
 -- JOIN	[10.4.1.3\sqlcldh02].[HealthInfoDB].[dbo].[mscForms] j
 --   ON	j.PK_mscForms = h.FK_mscForms
 -- JOIN	[10.4.1.3\sqlcldh02].[HealthInfoDB].[dbo].[Usertbl] k
	--ON	k.Username = h.userName
	JOIN	psDatacenter b
    ON	a.FK_emdPatients = b.PK_psDatacenter
  JOIN	psPersonaldata c
    ON	c.PK_psPersonalData = a.FK_emdPatients
  JOIN	emdPatients d
    ON	d.PK_emdPatients = a.FK_emdPatients
  JOIN	emdDoctors e
    ON	e.PK_emdDoctors = dbo.udf_GetAttendingDoctorsID(a.PK_psPatRegisters)
  JOIN	mscAdmResults f
    ON	f.PK_mscAdmResults = a.FK_mscAdmResults
  JOIN	mscServiceType g
    ON	g.PK_mscServiceType = a.FK_mscServiceType
  WHERE a.PK_psPatRegisters = 660426