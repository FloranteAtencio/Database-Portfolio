SELECT	h.qty,
		h.timestamp,
		j.formName,
		k.Lastname,
		k.Firstname, 
		k.Middlename,
		k.Position,
		j.FK_mscWarehouse,
		l.description as warehouse
  FROM	psPatRegisters a
  JOIN	[10.4.1.3\sqlcldh02].HealthInfoDB.dbo.psPatForms h
	ON	a.PK_psPatRegisters = h.FK_psPatRegisters
  JOIN	[10.4.1.3\sqlcldh02].HealthInfoDB.dbo.mscForms j
    ON	j.PK_mscForms = h.FK_mscForms
  JOIN	[10.4.1.3\sqlcldh02].HealthInfoDB.dbo.Usertbl k
	ON	k.Username = h.userName
  JOIN	mscWarehouse l
    ON	l.PK_mscWarehouse = j.fk_mscWarehouse
  
