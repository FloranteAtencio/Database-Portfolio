use HealthInfoDB;

drop table mscForms;

CREATE TABLE mscForms(
	[PK_mscForms] [int] IDENTITY(1,1) primary key,
	[FK_mscWarehouse] [int] NULL,
	[formName] [nvarchar](max) NULL,
	[isDisable] bit default 1
)