USE HealthInfoDB;

DROP TABLE IF EXISTS mscGroupChart;

CREATE TABLE mscGroupChart(
 PK_mscGroupChart INT PRIMARY KEY IDENTITY(1,1),
 GroupChart NVARCHAR(MAX)
);