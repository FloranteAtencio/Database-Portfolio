use HealthInfoDB;

DROP TABLE IF EXISTS  psPatForms;

Create table psPatForms(
PK_psPatForms INT IDENTITY (1,1) PRIMARY KEY,
FK_psPatRegisters INT,
FK_mscForms INT,
qty INT,
timeStamp DATETIME DEFAULT GETDATE(),
FK_user  INT
);